<?php

if (get_option('wpst_enable_seo_metadata')) {
    add_action('add_meta_boxes', 'wpst_add_seo_meta_box');
    add_action("save_post", "wpst_save_seo_meta_box", 10, 3);
    add_action('wp_head', 'wpst_seo_add_meta_tags');
} else {
    remove_action('add_meta_boxes', 'wpst_add_seo_meta_box');
    remove_action("save_post", "wpst_save_seo_meta_box", 10, 3);
    remove_action('wp_head', 'wpst_seo_add_meta_tags');
}


function wpst_add_seo_meta_box() {
    add_meta_box(
        'seo_meta_box', // id of the meta box
        'SEO Metadata', // title
        'wpst_display_seo_meta_box', // callback function
        'post', // screen or post type
        'normal' // context
    );
}

function wpst_seo_add_meta_tags() {
    if (is_single()) {
        $seo_title = get_post_meta(get_the_ID(), '_seo_title', true);
        $seo_description = get_post_meta(get_the_ID(), '_seo_description', true);
        if ($seo_title) {
            echo '<title>' . $seo_title . '</title>';
        }
        if ($seo_description) {
            echo '<meta name="description" content="' . $seo_description . '">';
        }
    }
}


function wpst_display_seo_meta_box($post) {
    $seo_title = get_post_meta($post->ID, '_seo_title', true);
    $seo_description = get_post_meta($post->ID, '_seo_description', true);
    ?>
    <table>
        <tr>
            <td style="width: 100%">SEO Title</td>
            <td><input type="text" size="80" name="seo_title" value="<?php echo $seo_title; ?>" /></td>
        </tr>
        <tr>
            <td style="width: 100%">SEO Description</td>
            <td><input type="text" size="80" name="seo_description" value="<?php echo $seo_description; ?>" /></td>
        </tr>
    </table>
    <?php
}

function wpst_save_seo_meta_box($post_id, $post, $update) {
    if (!isset($_POST["seo_title"]) || !isset($_POST["seo_description"])) {
        return $post_id;
    }

    $seo_title = $_POST["seo_title"];
    $seo_description = $_POST["seo_description"];

    update_post_meta($post_id, "_seo_title", $seo_title);
    update_post_meta($post_id, "_seo_description", $seo_description);
}